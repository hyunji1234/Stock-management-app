﻿namespace project
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.tbc_main = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.SSBVolume = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.SSBRate = new System.Windows.Forms.Label();
            this.SSBPrice = new System.Windows.Forms.Label();
            this.SSBDPrice = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.SKHVolume = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.SKHPrice = new System.Windows.Forms.Label();
            this.SKHDPrice = new System.Windows.Forms.Label();
            this.SKHRate = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.LGEVolume = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.LGERate = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.LGEDPrice = new System.Windows.Forms.Label();
            this.LGEPrice = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.SSVolume = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.SSRate = new System.Windows.Forms.Label();
            this.SSDPrice = new System.Windows.Forms.Label();
            this.SSPrice = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.POSCOVolume = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.POSCOPrice = new System.Windows.Forms.Label();
            this.POSCORate = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.POSCODPrice = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.SSEVolume = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.SSERate = new System.Windows.Forms.Label();
            this.SSEDPrice = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.SSEPrice = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.LGCVolume = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.LGCPrice = new System.Windows.Forms.Label();
            this.LGCDPrice = new System.Windows.Forms.Label();
            this.LGCRate = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.SSSVolume = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.SSSRate = new System.Windows.Forms.Label();
            this.SSSPrice = new System.Windows.Forms.Label();
            this.SSSDPrice = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.HDCVolume = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.HDCDPrice = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.HDCPrice = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.HDCRate = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.ECOVolume = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.ECORate = new System.Windows.Forms.Label();
            this.ECODPrice = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.ECOPrice = new System.Windows.Forms.Label();
            this.lbRT10 = new System.Windows.Forms.Label();
            this.lbRT9 = new System.Windows.Forms.Label();
            this.lbRT8 = new System.Windows.Forms.Label();
            this.lbRT7 = new System.Windows.Forms.Label();
            this.lbRT6 = new System.Windows.Forms.Label();
            this.lbRT5 = new System.Windows.Forms.Label();
            this.lbRT4 = new System.Windows.Forms.Label();
            this.lbRT3 = new System.Windows.Forms.Label();
            this.lbRT2 = new System.Windows.Forms.Label();
            this.lbRT1 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lbVO10 = new System.Windows.Forms.Label();
            this.lbVO9 = new System.Windows.Forms.Label();
            this.lbVO8 = new System.Windows.Forms.Label();
            this.lbVO6 = new System.Windows.Forms.Label();
            this.lbVO4 = new System.Windows.Forms.Label();
            this.lbVO5 = new System.Windows.Forms.Label();
            this.lbVO7 = new System.Windows.Forms.Label();
            this.lbVO3 = new System.Windows.Forms.Label();
            this.lbVO2 = new System.Windows.Forms.Label();
            this.lbVO1 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btn_10 = new System.Windows.Forms.Button();
            this.btn_ = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btnindex9 = new System.Windows.Forms.Button();
            this.btnindex8 = new System.Windows.Forms.Button();
            this.btnindex7 = new System.Windows.Forms.Button();
            this.btnindex6 = new System.Windows.Forms.Button();
            this.btnindex5 = new System.Windows.Forms.Button();
            this.btnindex4 = new System.Windows.Forms.Button();
            this.btnindex3 = new System.Windows.Forms.Button();
            this.btnindex2 = new System.Windows.Forms.Button();
            this.btnindex1 = new System.Windows.Forms.Button();
            this.btnindex0 = new System.Windows.Forms.Button();
            this.lv_ChartItem = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lv_interest = new System.Windows.Forms.ListView();
            this.interestItem = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.interestLast = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.interestRate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.interestMax = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.interestMin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage_save = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listViewHave = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSell = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbEvalution = new System.Windows.Forms.Label();
            this.lbRate3 = new System.Windows.Forms.Label();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbPrice2 = new System.Windows.Forms.Label();
            this.lbPrice = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lbStockName = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbPaL2 = new System.Windows.Forms.Label();
            this.lbPaL = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbRate2 = new System.Windows.Forms.Label();
            this.lbRate = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.lbPresentPrice2 = new System.Windows.Forms.Label();
            this.lbPresentPrice = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lbBuyPrice2 = new System.Windows.Forms.Label();
            this.lbBuyPrice = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lbBalance2 = new System.Windows.Forms.Label();
            this.lbBalance = new System.Windows.Forms.Label();
            this.lbName2 = new System.Windows.Forms.Label();
            this.tabPage_help = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_explain = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage_help_in = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_mainhome = new System.Windows.Forms.Button();
            this.btn_mainDomestic = new System.Windows.Forms.Button();
            this.btn_mainLogin = new System.Windows.Forms.Button();
            this.lb_loginname = new System.Windows.Forms.Label();
            this.btn_help = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_money = new System.Windows.Forms.Button();
            this.tbc_main.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage_save.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage_help.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage_explain.SuspendLayout();
            this.tabPage_help_in.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbc_main
            // 
            this.tbc_main.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tbc_main.Controls.Add(this.tabPage2);
            this.tbc_main.Controls.Add(this.tabPage1);
            this.tbc_main.Controls.Add(this.tabPage_save);
            this.tbc_main.Controls.Add(this.tabPage_help);
            this.tbc_main.ItemSize = new System.Drawing.Size(0, 1);
            this.tbc_main.Location = new System.Drawing.Point(6, 43);
            this.tbc_main.Name = "tbc_main";
            this.tbc_main.SelectedIndex = 0;
            this.tbc_main.Size = new System.Drawing.Size(610, 668);
            this.tbc_main.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tbc_main.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.txt_search);
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(602, 659);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "홈";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::project.Properties.Resources.돋보기_removebg_preview__1_;
            this.pictureBox2.Location = new System.Drawing.Point(569, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 30);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("맑은 고딕", 20F);
            this.label32.Location = new System.Drawing.Point(96, 12);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(410, 37);
            this.label32.TabIndex = 3;
            this.label32.Text = "로그인 후 이용하실 수 있습니다.";
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_search.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.txt_search.Location = new System.Drawing.Point(356, 6);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(206, 27);
            this.txt_search.TabIndex = 7;
            this.txt_search.Text = "종목명 또는 코드 입력";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Location = new System.Drawing.Point(2, 12);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(600, 642);
            this.tabControl3.TabIndex = 8;
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScrollMargin = new System.Drawing.Size(0, 30);
            this.tabPage5.Controls.Add(this.tableLayoutPanel1);
            this.tabPage5.Controls.Add(this.lbRT10);
            this.tabPage5.Controls.Add(this.lbRT9);
            this.tabPage5.Controls.Add(this.lbRT8);
            this.tabPage5.Controls.Add(this.lbRT7);
            this.tabPage5.Controls.Add(this.lbRT6);
            this.tabPage5.Controls.Add(this.lbRT5);
            this.tabPage5.Controls.Add(this.lbRT4);
            this.tabPage5.Controls.Add(this.lbRT3);
            this.tabPage5.Controls.Add(this.lbRT2);
            this.tabPage5.Controls.Add(this.lbRT1);
            this.tabPage5.Location = new System.Drawing.Point(4, 30);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Size = new System.Drawing.Size(592, 608);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "시가총액TOP10";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.panel11, 0, 10);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 22);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(590, 557);
            this.tableLayoutPanel1.TabIndex = 16;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.SSBVolume);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.SSBRate);
            this.panel5.Controls.Add(this.SSBPrice);
            this.panel5.Controls.Add(this.SSBDPrice);
            this.panel5.Location = new System.Drawing.Point(3, 203);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(584, 44);
            this.panel5.TabIndex = 2;
            this.panel5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel5_MouseClick);
            // 
            // SSBVolume
            // 
            this.SSBVolume.AutoSize = true;
            this.SSBVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSBVolume.Location = new System.Drawing.Point(514, 11);
            this.SSBVolume.Name = "SSBVolume";
            this.SSBVolume.Size = new System.Drawing.Size(55, 21);
            this.SSBVolume.TabIndex = 13;
            this.SSBVolume.Text = "36720";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.Location = new System.Drawing.Point(5, 5);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(138, 21);
            this.label24.TabIndex = 7;
            this.label24.Text = "삼성바이오로직스";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label19.Location = new System.Drawing.Point(5, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 15);
            this.label19.TabIndex = 8;
            this.label19.Text = "207940";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(364, 11);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 21);
            this.label23.TabIndex = 12;
            this.label23.Text = "562,986";
            // 
            // SSBRate
            // 
            this.SSBRate.AutoSize = true;
            this.SSBRate.BackColor = System.Drawing.Color.Blue;
            this.SSBRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.SSBRate.ForeColor = System.Drawing.Color.White;
            this.SSBRate.Location = new System.Drawing.Point(266, 12);
            this.SSBRate.Name = "SSBRate";
            this.SSBRate.Size = new System.Drawing.Size(36, 15);
            this.SSBRate.TabIndex = 11;
            this.SSBRate.Text = "-1.37";
            // 
            // SSBPrice
            // 
            this.SSBPrice.AutoSize = true;
            this.SSBPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSBPrice.Location = new System.Drawing.Point(191, 5);
            this.SSBPrice.Name = "SSBPrice";
            this.SSBPrice.Size = new System.Drawing.Size(64, 21);
            this.SSBPrice.TabIndex = 9;
            this.SSBPrice.Text = "791000";
            // 
            // SSBDPrice
            // 
            this.SSBDPrice.AutoSize = true;
            this.SSBDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.SSBDPrice.ForeColor = System.Drawing.Color.Blue;
            this.SSBDPrice.Location = new System.Drawing.Point(205, 25);
            this.SSBDPrice.Name = "SSBDPrice";
            this.SSBDPrice.Size = new System.Drawing.Size(47, 15);
            this.SSBDPrice.TabIndex = 10;
            this.SSBDPrice.Text = "-11000";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.SKHVolume);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.SKHPrice);
            this.panel4.Controls.Add(this.SKHDPrice);
            this.panel4.Controls.Add(this.SKHRate);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Location = new System.Drawing.Point(3, 153);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(584, 44);
            this.panel4.TabIndex = 2;
            this.panel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel4_MouseClick);
            // 
            // SKHVolume
            // 
            this.SKHVolume.AutoSize = true;
            this.SKHVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SKHVolume.Location = new System.Drawing.Point(492, 11);
            this.SKHVolume.Name = "SKHVolume";
            this.SKHVolume.Size = new System.Drawing.Size(73, 21);
            this.SKHVolume.TabIndex = 13;
            this.SKHVolume.Text = "1373472";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(5, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 21);
            this.label16.TabIndex = 7;
            this.label16.Text = "SK하이닉스";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(364, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 21);
            this.label17.TabIndex = 12;
            this.label17.Text = "888,163";
            // 
            // SKHPrice
            // 
            this.SKHPrice.AutoSize = true;
            this.SKHPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SKHPrice.Location = new System.Drawing.Point(189, 5);
            this.SKHPrice.Name = "SKHPrice";
            this.SKHPrice.Size = new System.Drawing.Size(64, 21);
            this.SKHPrice.TabIndex = 9;
            this.SKHPrice.Text = "122000";
            // 
            // SKHDPrice
            // 
            this.SKHDPrice.AutoSize = true;
            this.SKHDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.SKHDPrice.ForeColor = System.Drawing.Color.Blue;
            this.SKHDPrice.Location = new System.Drawing.Point(212, 25);
            this.SKHDPrice.Name = "SKHDPrice";
            this.SKHDPrice.Size = new System.Drawing.Size(40, 15);
            this.SKHDPrice.TabIndex = 10;
            this.SKHDPrice.Text = "-3100";
            // 
            // SKHRate
            // 
            this.SKHRate.AutoSize = true;
            this.SKHRate.BackColor = System.Drawing.Color.Blue;
            this.SKHRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.SKHRate.ForeColor = System.Drawing.Color.White;
            this.SKHRate.Location = new System.Drawing.Point(266, 12);
            this.SKHRate.Name = "SKHRate";
            this.SKHRate.Size = new System.Drawing.Size(36, 15);
            this.SKHRate.TabIndex = 11;
            this.SKHRate.Text = "-2.48";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label15.Location = new System.Drawing.Point(5, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 15);
            this.label15.TabIndex = 8;
            this.label15.Text = "000660";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.LGEVolume);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.LGERate);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.LGEDPrice);
            this.panel3.Controls.Add(this.LGEPrice);
            this.panel3.Location = new System.Drawing.Point(3, 103);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(584, 44);
            this.panel3.TabIndex = 2;
            this.panel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseClick);
            // 
            // LGEVolume
            // 
            this.LGEVolume.AutoSize = true;
            this.LGEVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LGEVolume.Location = new System.Drawing.Point(505, 11);
            this.LGEVolume.Name = "LGEVolume";
            this.LGEVolume.Size = new System.Drawing.Size(64, 21);
            this.LGEVolume.TabIndex = 13;
            this.LGEVolume.Text = "106265";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(364, 11);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 21);
            this.label18.TabIndex = 12;
            this.label18.Text = "1,284,660";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(5, 5);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(126, 21);
            this.label20.TabIndex = 7;
            this.label20.Text = "LG에너지솔루션";
            // 
            // LGERate
            // 
            this.LGERate.AutoSize = true;
            this.LGERate.BackColor = System.Drawing.Color.Blue;
            this.LGERate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.LGERate.ForeColor = System.Drawing.Color.White;
            this.LGERate.Location = new System.Drawing.Point(266, 12);
            this.LGERate.Name = "LGERate";
            this.LGERate.Size = new System.Drawing.Size(36, 15);
            this.LGERate.TabIndex = 11;
            this.LGERate.Text = "-1.44";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label21.Location = new System.Drawing.Point(5, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 15);
            this.label21.TabIndex = 8;
            this.label21.Text = "373220";
            // 
            // LGEDPrice
            // 
            this.LGEDPrice.AutoSize = true;
            this.LGEDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.LGEDPrice.ForeColor = System.Drawing.Color.Blue;
            this.LGEDPrice.Location = new System.Drawing.Point(212, 25);
            this.LGEDPrice.Name = "LGEDPrice";
            this.LGEDPrice.Size = new System.Drawing.Size(40, 15);
            this.LGEDPrice.TabIndex = 10;
            this.LGEDPrice.Text = "-8000";
            // 
            // LGEPrice
            // 
            this.LGEPrice.AutoSize = true;
            this.LGEPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LGEPrice.Location = new System.Drawing.Point(189, 5);
            this.LGEPrice.Name = "LGEPrice";
            this.LGEPrice.Size = new System.Drawing.Size(64, 21);
            this.LGEPrice.TabIndex = 9;
            this.LGEPrice.Text = "392000";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 44);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-3, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(584, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.SSVolume);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.SSRate);
            this.panel2.Controls.Add(this.SSDPrice);
            this.panel2.Controls.Add(this.SSPrice);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(3, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(584, 44);
            this.panel2.TabIndex = 1;
            this.panel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseClick);
            // 
            // SSVolume
            // 
            this.SSVolume.AutoSize = true;
            this.SSVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSVolume.Location = new System.Drawing.Point(492, 11);
            this.SSVolume.Name = "SSVolume";
            this.SSVolume.Size = new System.Drawing.Size(73, 21);
            this.SSVolume.TabIndex = 6;
            this.SSVolume.Text = "5733419";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(364, 11);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(81, 21);
            this.label22.TabIndex = 5;
            this.label22.Text = "4,202,727";
            // 
            // SSRate
            // 
            this.SSRate.AutoSize = true;
            this.SSRate.BackColor = System.Drawing.Color.Blue;
            this.SSRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.SSRate.ForeColor = System.Drawing.Color.White;
            this.SSRate.Location = new System.Drawing.Point(266, 12);
            this.SSRate.Name = "SSRate";
            this.SSRate.Size = new System.Drawing.Size(36, 15);
            this.SSRate.TabIndex = 4;
            this.SSRate.Text = "-0.98";
            // 
            // SSDPrice
            // 
            this.SSDPrice.AutoSize = true;
            this.SSDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.SSDPrice.ForeColor = System.Drawing.Color.Blue;
            this.SSDPrice.Location = new System.Drawing.Point(219, 25);
            this.SSDPrice.Name = "SSDPrice";
            this.SSDPrice.Size = new System.Drawing.Size(33, 15);
            this.SSDPrice.TabIndex = 3;
            this.SSDPrice.Text = "-700";
            // 
            // SSPrice
            // 
            this.SSPrice.AutoSize = true;
            this.SSPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSPrice.Location = new System.Drawing.Point(200, 5);
            this.SSPrice.Name = "SSPrice";
            this.SSPrice.Size = new System.Drawing.Size(55, 21);
            this.SSPrice.TabIndex = 2;
            this.SSPrice.Text = "70400";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label26.Location = new System.Drawing.Point(5, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(49, 15);
            this.label26.TabIndex = 1;
            this.label26.Text = "005930";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.Location = new System.Drawing.Point(5, 5);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 21);
            this.label27.TabIndex = 0;
            this.label27.Text = "삼성전자";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.POSCOVolume);
            this.panel6.Controls.Add(this.label38);
            this.panel6.Controls.Add(this.POSCOPrice);
            this.panel6.Controls.Add(this.POSCORate);
            this.panel6.Controls.Add(this.label34);
            this.panel6.Controls.Add(this.POSCODPrice);
            this.panel6.Controls.Add(this.label35);
            this.panel6.Location = new System.Drawing.Point(3, 253);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(584, 44);
            this.panel6.TabIndex = 2;
            this.panel6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel6_MouseClick);
            // 
            // POSCOVolume
            // 
            this.POSCOVolume.AutoSize = true;
            this.POSCOVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.POSCOVolume.Location = new System.Drawing.Point(492, 11);
            this.POSCOVolume.Name = "POSCOVolume";
            this.POSCOVolume.Size = new System.Drawing.Size(73, 21);
            this.POSCOVolume.TabIndex = 13;
            this.POSCOVolume.Text = "1318866";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label38.Location = new System.Drawing.Point(5, 5);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(111, 21);
            this.label38.TabIndex = 7;
            this.label38.Text = "POSCO홀딩스";
            this.label38.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // POSCOPrice
            // 
            this.POSCOPrice.AutoSize = true;
            this.POSCOPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.POSCOPrice.Location = new System.Drawing.Point(191, 5);
            this.POSCOPrice.Name = "POSCOPrice";
            this.POSCOPrice.Size = new System.Drawing.Size(64, 21);
            this.POSCOPrice.TabIndex = 9;
            this.POSCOPrice.Text = "600000";
            // 
            // POSCORate
            // 
            this.POSCORate.AutoSize = true;
            this.POSCORate.BackColor = System.Drawing.Color.Blue;
            this.POSCORate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.POSCORate.ForeColor = System.Drawing.Color.White;
            this.POSCORate.Location = new System.Drawing.Point(266, 12);
            this.POSCORate.Name = "POSCORate";
            this.POSCORate.Size = new System.Drawing.Size(36, 15);
            this.POSCORate.TabIndex = 11;
            this.POSCORate.Text = "-3.38";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label34.Location = new System.Drawing.Point(5, 25);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(49, 15);
            this.label34.TabIndex = 8;
            this.label34.Text = "005490";
            // 
            // POSCODPrice
            // 
            this.POSCODPrice.AutoSize = true;
            this.POSCODPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.POSCODPrice.ForeColor = System.Drawing.Color.Blue;
            this.POSCODPrice.Location = new System.Drawing.Point(205, 25);
            this.POSCODPrice.Name = "POSCODPrice";
            this.POSCODPrice.Size = new System.Drawing.Size(47, 15);
            this.POSCODPrice.TabIndex = 10;
            this.POSCODPrice.Text = "-21000";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label35.Location = new System.Drawing.Point(364, 11);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 21);
            this.label35.TabIndex = 12;
            this.label35.Text = "507,427";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.SSEVolume);
            this.panel7.Controls.Add(this.label31);
            this.panel7.Controls.Add(this.SSERate);
            this.panel7.Controls.Add(this.SSEDPrice);
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.label30);
            this.panel7.Controls.Add(this.SSEPrice);
            this.panel7.Location = new System.Drawing.Point(3, 303);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(584, 44);
            this.panel7.TabIndex = 2;
            this.panel7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel7_MouseClick);
            // 
            // SSEVolume
            // 
            this.SSEVolume.AutoSize = true;
            this.SSEVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSEVolume.Location = new System.Drawing.Point(505, 11);
            this.SSEVolume.Name = "SSEVolume";
            this.SSEVolume.Size = new System.Drawing.Size(64, 21);
            this.SSEVolume.TabIndex = 13;
            this.SSEVolume.Text = "551237";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.Location = new System.Drawing.Point(5, 5);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(122, 21);
            this.label31.TabIndex = 7;
            this.label31.Text = "삼성전자우량주";
            // 
            // SSERate
            // 
            this.SSERate.AutoSize = true;
            this.SSERate.BackColor = System.Drawing.Color.Blue;
            this.SSERate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.SSERate.ForeColor = System.Drawing.Color.White;
            this.SSERate.Location = new System.Drawing.Point(266, 12);
            this.SSERate.Name = "SSERate";
            this.SSERate.Size = new System.Drawing.Size(36, 15);
            this.SSERate.TabIndex = 11;
            this.SSERate.Text = "-0.17";
            // 
            // SSEDPrice
            // 
            this.SSEDPrice.AutoSize = true;
            this.SSEDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.SSEDPrice.ForeColor = System.Drawing.Color.Blue;
            this.SSEDPrice.Location = new System.Drawing.Point(219, 25);
            this.SSEDPrice.Name = "SSEDPrice";
            this.SSEDPrice.Size = new System.Drawing.Size(33, 15);
            this.SSEDPrice.TabIndex = 10;
            this.SSEDPrice.Text = "-100";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label29.Location = new System.Drawing.Point(364, 11);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(68, 21);
            this.label29.TabIndex = 12;
            this.label29.Text = "477,274";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label30.Location = new System.Drawing.Point(5, 25);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(49, 15);
            this.label30.TabIndex = 8;
            this.label30.Text = "005935";
            // 
            // SSEPrice
            // 
            this.SSEPrice.AutoSize = true;
            this.SSEPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSEPrice.Location = new System.Drawing.Point(200, 5);
            this.SSEPrice.Name = "SSEPrice";
            this.SSEPrice.Size = new System.Drawing.Size(55, 21);
            this.SSEPrice.TabIndex = 9;
            this.SSEPrice.Text = "58000";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.LGCVolume);
            this.panel8.Controls.Add(this.label45);
            this.panel8.Controls.Add(this.label40);
            this.panel8.Controls.Add(this.LGCPrice);
            this.panel8.Controls.Add(this.LGCDPrice);
            this.panel8.Controls.Add(this.LGCRate);
            this.panel8.Controls.Add(this.label42);
            this.panel8.Location = new System.Drawing.Point(3, 353);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(584, 44);
            this.panel8.TabIndex = 2;
            this.panel8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel8_MouseClick);
            // 
            // LGCVolume
            // 
            this.LGCVolume.AutoSize = true;
            this.LGCVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LGCVolume.Location = new System.Drawing.Point(505, 11);
            this.LGCVolume.Name = "LGCVolume";
            this.LGCVolume.Size = new System.Drawing.Size(64, 21);
            this.LGCVolume.TabIndex = 13;
            this.LGCVolume.Text = "136694";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label45.Location = new System.Drawing.Point(5, 5);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(62, 21);
            this.label45.TabIndex = 7;
            this.label45.Text = "LG화학";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label40.Location = new System.Drawing.Point(364, 11);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 21);
            this.label40.TabIndex = 12;
            this.label40.Text = "458,144";
            // 
            // LGCPrice
            // 
            this.LGCPrice.AutoSize = true;
            this.LGCPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.LGCPrice.Location = new System.Drawing.Point(191, 5);
            this.LGCPrice.Name = "LGCPrice";
            this.LGCPrice.Size = new System.Drawing.Size(64, 21);
            this.LGCPrice.TabIndex = 9;
            this.LGCPrice.Text = "649000";
            // 
            // LGCDPrice
            // 
            this.LGCDPrice.AutoSize = true;
            this.LGCDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.LGCDPrice.ForeColor = System.Drawing.Color.Blue;
            this.LGCDPrice.Location = new System.Drawing.Point(212, 25);
            this.LGCDPrice.Name = "LGCDPrice";
            this.LGCDPrice.Size = new System.Drawing.Size(40, 15);
            this.LGCDPrice.TabIndex = 10;
            this.LGCDPrice.Text = "-6000";
            // 
            // LGCRate
            // 
            this.LGCRate.AutoSize = true;
            this.LGCRate.BackColor = System.Drawing.Color.Blue;
            this.LGCRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.LGCRate.ForeColor = System.Drawing.Color.White;
            this.LGCRate.Location = new System.Drawing.Point(266, 12);
            this.LGCRate.Name = "LGCRate";
            this.LGCRate.Size = new System.Drawing.Size(36, 15);
            this.LGCRate.TabIndex = 11;
            this.LGCRate.Text = "-0.92";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label42.Location = new System.Drawing.Point(5, 25);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(49, 15);
            this.label42.TabIndex = 8;
            this.label42.Text = "051910";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.SSSVolume);
            this.panel9.Controls.Add(this.label52);
            this.panel9.Controls.Add(this.label47);
            this.panel9.Controls.Add(this.label51);
            this.panel9.Controls.Add(this.SSSRate);
            this.panel9.Controls.Add(this.SSSPrice);
            this.panel9.Controls.Add(this.SSSDPrice);
            this.panel9.Location = new System.Drawing.Point(3, 403);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(584, 44);
            this.panel9.TabIndex = 2;
            this.panel9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel9_MouseClick);
            // 
            // SSSVolume
            // 
            this.SSSVolume.AutoSize = true;
            this.SSSVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSSVolume.Location = new System.Drawing.Point(505, 11);
            this.SSSVolume.Name = "SSSVolume";
            this.SSSVolume.Size = new System.Drawing.Size(64, 21);
            this.SSSVolume.TabIndex = 13;
            this.SSSVolume.Text = "116740";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label52.Location = new System.Drawing.Point(5, 5);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(68, 21);
            this.label52.TabIndex = 7;
            this.label52.Text = "삼성SDI";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label47.Location = new System.Drawing.Point(5, 25);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(49, 15);
            this.label47.TabIndex = 8;
            this.label47.Text = "006400";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label51.Location = new System.Drawing.Point(364, 15);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(68, 21);
            this.label51.TabIndex = 12;
            this.label51.Text = "450,408";
            // 
            // SSSRate
            // 
            this.SSSRate.AutoSize = true;
            this.SSSRate.BackColor = System.Drawing.Color.Blue;
            this.SSSRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.SSSRate.ForeColor = System.Drawing.Color.White;
            this.SSSRate.Location = new System.Drawing.Point(266, 12);
            this.SSSRate.Name = "SSSRate";
            this.SSSRate.Size = new System.Drawing.Size(36, 15);
            this.SSSRate.TabIndex = 11;
            this.SSSRate.Text = "-2.24";
            // 
            // SSSPrice
            // 
            this.SSSPrice.AutoSize = true;
            this.SSSPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SSSPrice.Location = new System.Drawing.Point(191, 5);
            this.SSSPrice.Name = "SSSPrice";
            this.SSSPrice.Size = new System.Drawing.Size(64, 21);
            this.SSSPrice.TabIndex = 9;
            this.SSSPrice.Text = "655000";
            // 
            // SSSDPrice
            // 
            this.SSSDPrice.AutoSize = true;
            this.SSSDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.SSSDPrice.ForeColor = System.Drawing.Color.Blue;
            this.SSSDPrice.Location = new System.Drawing.Point(205, 25);
            this.SSSDPrice.Name = "SSSDPrice";
            this.SSSDPrice.Size = new System.Drawing.Size(47, 15);
            this.SSSDPrice.TabIndex = 10;
            this.SSSDPrice.Text = "-15000";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.HDCVolume);
            this.panel10.Controls.Add(this.label59);
            this.panel10.Controls.Add(this.HDCDPrice);
            this.panel10.Controls.Add(this.label58);
            this.panel10.Controls.Add(this.HDCPrice);
            this.panel10.Controls.Add(this.label57);
            this.panel10.Controls.Add(this.HDCRate);
            this.panel10.Location = new System.Drawing.Point(3, 453);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(584, 44);
            this.panel10.TabIndex = 2;
            this.panel10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel10_MouseClick);
            // 
            // HDCVolume
            // 
            this.HDCVolume.AutoSize = true;
            this.HDCVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.HDCVolume.Location = new System.Drawing.Point(505, 11);
            this.HDCVolume.Name = "HDCVolume";
            this.HDCVolume.Size = new System.Drawing.Size(64, 21);
            this.HDCVolume.TabIndex = 13;
            this.HDCVolume.Text = "340396";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label59.Location = new System.Drawing.Point(5, 5);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(58, 21);
            this.label59.TabIndex = 7;
            this.label59.Text = "현대차";
            // 
            // HDCDPrice
            // 
            this.HDCDPrice.AutoSize = true;
            this.HDCDPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.HDCDPrice.ForeColor = System.Drawing.Color.Blue;
            this.HDCDPrice.Location = new System.Drawing.Point(219, 25);
            this.HDCDPrice.Name = "HDCDPrice";
            this.HDCDPrice.Size = new System.Drawing.Size(33, 15);
            this.HDCDPrice.TabIndex = 10;
            this.HDCDPrice.Text = "-700";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label58.Location = new System.Drawing.Point(5, 25);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(49, 15);
            this.label58.TabIndex = 8;
            this.label58.Text = "005380";
            // 
            // HDCPrice
            // 
            this.HDCPrice.AutoSize = true;
            this.HDCPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.HDCPrice.Location = new System.Drawing.Point(191, 5);
            this.HDCPrice.Name = "HDCPrice";
            this.HDCPrice.Size = new System.Drawing.Size(64, 21);
            this.HDCPrice.TabIndex = 9;
            this.HDCPrice.Text = "195600";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label57.Location = new System.Drawing.Point(364, 15);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(68, 21);
            this.label57.TabIndex = 12;
            this.label57.Text = "413,756";
            // 
            // HDCRate
            // 
            this.HDCRate.AutoSize = true;
            this.HDCRate.BackColor = System.Drawing.Color.Blue;
            this.HDCRate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.HDCRate.ForeColor = System.Drawing.Color.White;
            this.HDCRate.Location = new System.Drawing.Point(266, 16);
            this.HDCRate.Name = "HDCRate";
            this.HDCRate.Size = new System.Drawing.Size(36, 15);
            this.HDCRate.TabIndex = 11;
            this.HDCRate.Text = "-3.36";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.ECOVolume);
            this.panel11.Controls.Add(this.label66);
            this.panel11.Controls.Add(this.ECORate);
            this.panel11.Controls.Add(this.ECODPrice);
            this.panel11.Controls.Add(this.label62);
            this.panel11.Controls.Add(this.label64);
            this.panel11.Controls.Add(this.ECOPrice);
            this.panel11.Location = new System.Drawing.Point(3, 503);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(584, 48);
            this.panel11.TabIndex = 2;
            this.panel11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panel11_MouseClick);
            // 
            // ECOVolume
            // 
            this.ECOVolume.AutoSize = true;
            this.ECOVolume.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ECOVolume.Location = new System.Drawing.Point(492, 12);
            this.ECOVolume.Name = "ECOVolume";
            this.ECOVolume.Size = new System.Drawing.Size(73, 21);
            this.ECOVolume.TabIndex = 13;
            this.ECOVolume.Text = "1464417";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label66.Location = new System.Drawing.Point(5, 6);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(106, 21);
            this.label66.TabIndex = 7;
            this.label66.Text = "에코프로비엠";
            // 
            // ECORate
            // 
            this.ECORate.AutoSize = true;
            this.ECORate.BackColor = System.Drawing.Color.Blue;
            this.ECORate.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold);
            this.ECORate.ForeColor = System.Drawing.Color.White;
            this.ECORate.Location = new System.Drawing.Point(266, 17);
            this.ECORate.Name = "ECORate";
            this.ECORate.Size = new System.Drawing.Size(36, 15);
            this.ECORate.TabIndex = 11;
            this.ECORate.Text = "-5.02";
            // 
            // ECODPrice
            // 
            this.ECODPrice.AutoSize = true;
            this.ECODPrice.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.ECODPrice.ForeColor = System.Drawing.Color.Blue;
            this.ECODPrice.Location = new System.Drawing.Point(205, 26);
            this.ECODPrice.Name = "ECODPrice";
            this.ECODPrice.Size = new System.Drawing.Size(47, 15);
            this.ECODPrice.TabIndex = 10;
            this.ECODPrice.Text = "-20500";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label62.Location = new System.Drawing.Point(364, 12);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(68, 21);
            this.label62.TabIndex = 12;
            this.label62.Text = "379,469";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.label64.Location = new System.Drawing.Point(5, 26);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(49, 15);
            this.label64.TabIndex = 8;
            this.label64.Text = "247540";
            // 
            // ECOPrice
            // 
            this.ECOPrice.AutoSize = true;
            this.ECOPrice.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ECOPrice.Location = new System.Drawing.Point(191, 6);
            this.ECOPrice.Name = "ECOPrice";
            this.ECOPrice.Size = new System.Drawing.Size(64, 21);
            this.ECOPrice.TabIndex = 9;
            this.ECOPrice.Text = "388000";
            // 
            // lbRT10
            // 
            this.lbRT10.AutoSize = true;
            this.lbRT10.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT10.Location = new System.Drawing.Point(50, 475);
            this.lbRT10.Name = "lbRT10";
            this.lbRT10.Size = new System.Drawing.Size(35, 17);
            this.lbRT10.TabIndex = 15;
            this.lbRT10.Text = "10위";
            // 
            // lbRT9
            // 
            this.lbRT9.AutoSize = true;
            this.lbRT9.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT9.Location = new System.Drawing.Point(50, 425);
            this.lbRT9.Name = "lbRT9";
            this.lbRT9.Size = new System.Drawing.Size(28, 17);
            this.lbRT9.TabIndex = 14;
            this.lbRT9.Text = "9위";
            // 
            // lbRT8
            // 
            this.lbRT8.AutoSize = true;
            this.lbRT8.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT8.Location = new System.Drawing.Point(50, 375);
            this.lbRT8.Name = "lbRT8";
            this.lbRT8.Size = new System.Drawing.Size(28, 17);
            this.lbRT8.TabIndex = 13;
            this.lbRT8.Text = "8위";
            // 
            // lbRT7
            // 
            this.lbRT7.AutoSize = true;
            this.lbRT7.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT7.Location = new System.Drawing.Point(50, 325);
            this.lbRT7.Name = "lbRT7";
            this.lbRT7.Size = new System.Drawing.Size(28, 17);
            this.lbRT7.TabIndex = 12;
            this.lbRT7.Text = "7위";
            // 
            // lbRT6
            // 
            this.lbRT6.AutoSize = true;
            this.lbRT6.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT6.Location = new System.Drawing.Point(50, 275);
            this.lbRT6.Name = "lbRT6";
            this.lbRT6.Size = new System.Drawing.Size(28, 17);
            this.lbRT6.TabIndex = 11;
            this.lbRT6.Text = "6위";
            // 
            // lbRT5
            // 
            this.lbRT5.AutoSize = true;
            this.lbRT5.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT5.Location = new System.Drawing.Point(50, 225);
            this.lbRT5.Name = "lbRT5";
            this.lbRT5.Size = new System.Drawing.Size(28, 17);
            this.lbRT5.TabIndex = 10;
            this.lbRT5.Text = "5위";
            // 
            // lbRT4
            // 
            this.lbRT4.AutoSize = true;
            this.lbRT4.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbRT4.Location = new System.Drawing.Point(50, 175);
            this.lbRT4.Name = "lbRT4";
            this.lbRT4.Size = new System.Drawing.Size(28, 17);
            this.lbRT4.TabIndex = 9;
            this.lbRT4.Text = "4위";
            // 
            // lbRT3
            // 
            this.lbRT3.AutoSize = true;
            this.lbRT3.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.lbRT3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbRT3.Location = new System.Drawing.Point(50, 125);
            this.lbRT3.Name = "lbRT3";
            this.lbRT3.Size = new System.Drawing.Size(35, 21);
            this.lbRT3.TabIndex = 8;
            this.lbRT3.Text = "3위";
            // 
            // lbRT2
            // 
            this.lbRT2.AutoSize = true;
            this.lbRT2.Font = new System.Drawing.Font("맑은 고딕", 15.75F);
            this.lbRT2.ForeColor = System.Drawing.Color.DarkOrange;
            this.lbRT2.Location = new System.Drawing.Point(50, 75);
            this.lbRT2.Name = "lbRT2";
            this.lbRT2.Size = new System.Drawing.Size(46, 30);
            this.lbRT2.TabIndex = 7;
            this.lbRT2.Text = "2위";
            // 
            // lbRT1
            // 
            this.lbRT1.AutoSize = true;
            this.lbRT1.Font = new System.Drawing.Font("맑은 고딕", 20.25F);
            this.lbRT1.ForeColor = System.Drawing.Color.Red;
            this.lbRT1.Location = new System.Drawing.Point(50, 20);
            this.lbRT1.Name = "lbRT1";
            this.lbRT1.Size = new System.Drawing.Size(59, 37);
            this.lbRT1.TabIndex = 6;
            this.lbRT1.Text = "1위";
            // 
            // tabPage6
            // 
            this.tabPage6.AutoScroll = true;
            this.tabPage6.AutoScrollMargin = new System.Drawing.Size(0, 30);
            this.tabPage6.Controls.Add(this.lbVO10);
            this.tabPage6.Controls.Add(this.lbVO9);
            this.tabPage6.Controls.Add(this.lbVO8);
            this.tabPage6.Controls.Add(this.lbVO6);
            this.tabPage6.Controls.Add(this.lbVO4);
            this.tabPage6.Controls.Add(this.lbVO5);
            this.tabPage6.Controls.Add(this.lbVO7);
            this.tabPage6.Controls.Add(this.lbVO3);
            this.tabPage6.Controls.Add(this.lbVO2);
            this.tabPage6.Controls.Add(this.lbVO1);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Size = new System.Drawing.Size(592, 616);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "거래량";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // lbVO10
            // 
            this.lbVO10.AutoSize = true;
            this.lbVO10.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO10.Location = new System.Drawing.Point(50, 475);
            this.lbVO10.Name = "lbVO10";
            this.lbVO10.Size = new System.Drawing.Size(35, 17);
            this.lbVO10.TabIndex = 9;
            this.lbVO10.Text = "10위";
            // 
            // lbVO9
            // 
            this.lbVO9.AutoSize = true;
            this.lbVO9.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO9.Location = new System.Drawing.Point(50, 425);
            this.lbVO9.Name = "lbVO9";
            this.lbVO9.Size = new System.Drawing.Size(28, 17);
            this.lbVO9.TabIndex = 8;
            this.lbVO9.Text = "9위";
            // 
            // lbVO8
            // 
            this.lbVO8.AutoSize = true;
            this.lbVO8.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO8.Location = new System.Drawing.Point(50, 375);
            this.lbVO8.Name = "lbVO8";
            this.lbVO8.Size = new System.Drawing.Size(28, 17);
            this.lbVO8.TabIndex = 7;
            this.lbVO8.Text = "8위";
            // 
            // lbVO6
            // 
            this.lbVO6.AutoSize = true;
            this.lbVO6.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO6.Location = new System.Drawing.Point(50, 275);
            this.lbVO6.Name = "lbVO6";
            this.lbVO6.Size = new System.Drawing.Size(28, 17);
            this.lbVO6.TabIndex = 6;
            this.lbVO6.Text = "6위";
            // 
            // lbVO4
            // 
            this.lbVO4.AutoSize = true;
            this.lbVO4.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO4.Location = new System.Drawing.Point(50, 175);
            this.lbVO4.Name = "lbVO4";
            this.lbVO4.Size = new System.Drawing.Size(28, 17);
            this.lbVO4.TabIndex = 5;
            this.lbVO4.Text = "4위";
            // 
            // lbVO5
            // 
            this.lbVO5.AutoSize = true;
            this.lbVO5.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO5.Location = new System.Drawing.Point(50, 225);
            this.lbVO5.Name = "lbVO5";
            this.lbVO5.Size = new System.Drawing.Size(28, 17);
            this.lbVO5.TabIndex = 4;
            this.lbVO5.Text = "5위";
            // 
            // lbVO7
            // 
            this.lbVO7.AutoSize = true;
            this.lbVO7.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.lbVO7.Location = new System.Drawing.Point(50, 325);
            this.lbVO7.Name = "lbVO7";
            this.lbVO7.Size = new System.Drawing.Size(28, 17);
            this.lbVO7.TabIndex = 3;
            this.lbVO7.Text = "7위";
            // 
            // lbVO3
            // 
            this.lbVO3.AutoSize = true;
            this.lbVO3.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.lbVO3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.lbVO3.Location = new System.Drawing.Point(50, 125);
            this.lbVO3.Name = "lbVO3";
            this.lbVO3.Size = new System.Drawing.Size(35, 21);
            this.lbVO3.TabIndex = 2;
            this.lbVO3.Text = "3위";
            // 
            // lbVO2
            // 
            this.lbVO2.AutoSize = true;
            this.lbVO2.Font = new System.Drawing.Font("맑은 고딕", 15.75F);
            this.lbVO2.ForeColor = System.Drawing.Color.DarkOrange;
            this.lbVO2.Location = new System.Drawing.Point(50, 75);
            this.lbVO2.Name = "lbVO2";
            this.lbVO2.Size = new System.Drawing.Size(46, 30);
            this.lbVO2.TabIndex = 1;
            this.lbVO2.Text = "2위";
            // 
            // lbVO1
            // 
            this.lbVO1.AutoSize = true;
            this.lbVO1.Font = new System.Drawing.Font("맑은 고딕", 20.25F);
            this.lbVO1.ForeColor = System.Drawing.Color.Red;
            this.lbVO1.Location = new System.Drawing.Point(50, 20);
            this.lbVO1.Name = "lbVO1";
            this.lbVO1.Size = new System.Drawing.Size(59, 37);
            this.lbVO1.TabIndex = 0;
            this.lbVO1.Text = "1위";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(602, 659);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "국내";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl2.ItemSize = new System.Drawing.Size(222, 21);
            this.tabControl2.Location = new System.Drawing.Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(587, 647);
            this.tabControl2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btn_10);
            this.tabPage3.Controls.Add(this.btn_);
            this.tabPage3.Controls.Add(this.btn_4);
            this.tabPage3.Controls.Add(this.btn_9);
            this.tabPage3.Controls.Add(this.btn_7);
            this.tabPage3.Controls.Add(this.btn_3);
            this.tabPage3.Controls.Add(this.btn_6);
            this.tabPage3.Controls.Add(this.btn_2);
            this.tabPage3.Controls.Add(this.btn_5);
            this.tabPage3.Controls.Add(this.btn_1);
            this.tabPage3.Controls.Add(this.btnindex9);
            this.tabPage3.Controls.Add(this.btnindex8);
            this.tabPage3.Controls.Add(this.btnindex7);
            this.tabPage3.Controls.Add(this.btnindex6);
            this.tabPage3.Controls.Add(this.btnindex5);
            this.tabPage3.Controls.Add(this.btnindex4);
            this.tabPage3.Controls.Add(this.btnindex3);
            this.tabPage3.Controls.Add(this.btnindex2);
            this.tabPage3.Controls.Add(this.btnindex1);
            this.tabPage3.Controls.Add(this.btnindex0);
            this.tabPage3.Controls.Add(this.lv_ChartItem);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(579, 618);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "인기목록";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btn_10
            // 
            this.btn_10.BackColor = System.Drawing.Color.Blue;
            this.btn_10.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_10.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_10.ForeColor = System.Drawing.Color.White;
            this.btn_10.Location = new System.Drawing.Point(493, 445);
            this.btn_10.Name = "btn_10";
            this.btn_10.Size = new System.Drawing.Size(61, 39);
            this.btn_10.TabIndex = 3;
            this.btn_10.Text = "구매";
            this.btn_10.UseVisualStyleBackColor = false;
            this.btn_10.Click += new System.EventHandler(this.btn_10_Click);
            // 
            // btn_
            // 
            this.btn_.BackColor = System.Drawing.Color.Blue;
            this.btn_.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_.ForeColor = System.Drawing.Color.White;
            this.btn_.Location = new System.Drawing.Point(493, 355);
            this.btn_.Name = "btn_";
            this.btn_.Size = new System.Drawing.Size(61, 39);
            this.btn_.TabIndex = 3;
            this.btn_.Text = "구매";
            this.btn_.UseVisualStyleBackColor = false;
            this.btn_.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.Blue;
            this.btn_4.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_4.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_4.ForeColor = System.Drawing.Color.White;
            this.btn_4.Location = new System.Drawing.Point(493, 173);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(61, 39);
            this.btn_4.TabIndex = 3;
            this.btn_4.Text = "구매";
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.Blue;
            this.btn_9.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_9.ForeColor = System.Drawing.Color.White;
            this.btn_9.Location = new System.Drawing.Point(493, 400);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(61, 39);
            this.btn_9.TabIndex = 4;
            this.btn_9.Text = "구매";
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.Blue;
            this.btn_7.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_7.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_7.ForeColor = System.Drawing.Color.White;
            this.btn_7.Location = new System.Drawing.Point(493, 310);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(61, 39);
            this.btn_7.TabIndex = 4;
            this.btn_7.Text = "구매";
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.Blue;
            this.btn_3.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_3.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_3.ForeColor = System.Drawing.Color.White;
            this.btn_3.Location = new System.Drawing.Point(493, 128);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(61, 39);
            this.btn_3.TabIndex = 4;
            this.btn_3.Text = "구매";
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.Blue;
            this.btn_6.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_6.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_6.ForeColor = System.Drawing.Color.White;
            this.btn_6.Location = new System.Drawing.Point(493, 265);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(61, 39);
            this.btn_6.TabIndex = 5;
            this.btn_6.Text = "구매";
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.Blue;
            this.btn_2.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_2.ForeColor = System.Drawing.Color.White;
            this.btn_2.Location = new System.Drawing.Point(493, 83);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(61, 39);
            this.btn_2.TabIndex = 5;
            this.btn_2.Text = "구매";
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.Blue;
            this.btn_5.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_5.ForeColor = System.Drawing.Color.White;
            this.btn_5.Location = new System.Drawing.Point(493, 220);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(61, 39);
            this.btn_5.TabIndex = 6;
            this.btn_5.Text = "구매";
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.Blue;
            this.btn_1.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.btn_1.ForeColor = System.Drawing.Color.White;
            this.btn_1.Location = new System.Drawing.Point(493, 36);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(61, 39);
            this.btn_1.TabIndex = 6;
            this.btn_1.Text = "구매";
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btnindex9
            // 
            this.btnindex9.FlatAppearance.BorderSize = 0;
            this.btnindex9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex9.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex9.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex9.Location = new System.Drawing.Point(442, 438);
            this.btnindex9.Name = "btnindex9";
            this.btnindex9.Size = new System.Drawing.Size(37, 39);
            this.btnindex9.TabIndex = 1;
            this.btnindex9.Text = "☆";
            this.btnindex9.UseVisualStyleBackColor = true;
            this.btnindex9.Click += new System.EventHandler(this.btnindex9_Click);
            // 
            // btnindex8
            // 
            this.btnindex8.FlatAppearance.BorderSize = 0;
            this.btnindex8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex8.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex8.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex8.Location = new System.Drawing.Point(442, 393);
            this.btnindex8.Name = "btnindex8";
            this.btnindex8.Size = new System.Drawing.Size(37, 39);
            this.btnindex8.TabIndex = 1;
            this.btnindex8.Text = "☆";
            this.btnindex8.UseVisualStyleBackColor = true;
            this.btnindex8.Click += new System.EventHandler(this.btnindex8_Click);
            // 
            // btnindex7
            // 
            this.btnindex7.FlatAppearance.BorderSize = 0;
            this.btnindex7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex7.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex7.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex7.Location = new System.Drawing.Point(442, 348);
            this.btnindex7.Name = "btnindex7";
            this.btnindex7.Size = new System.Drawing.Size(37, 39);
            this.btnindex7.TabIndex = 1;
            this.btnindex7.Text = "☆";
            this.btnindex7.UseVisualStyleBackColor = true;
            this.btnindex7.Click += new System.EventHandler(this.btnindex7_Click);
            // 
            // btnindex6
            // 
            this.btnindex6.FlatAppearance.BorderSize = 0;
            this.btnindex6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex6.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex6.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex6.Location = new System.Drawing.Point(442, 303);
            this.btnindex6.Name = "btnindex6";
            this.btnindex6.Size = new System.Drawing.Size(37, 39);
            this.btnindex6.TabIndex = 1;
            this.btnindex6.Text = "☆";
            this.btnindex6.UseVisualStyleBackColor = true;
            this.btnindex6.Click += new System.EventHandler(this.btnindex6_Click);
            // 
            // btnindex5
            // 
            this.btnindex5.FlatAppearance.BorderSize = 0;
            this.btnindex5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex5.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex5.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex5.Location = new System.Drawing.Point(442, 258);
            this.btnindex5.Name = "btnindex5";
            this.btnindex5.Size = new System.Drawing.Size(37, 39);
            this.btnindex5.TabIndex = 1;
            this.btnindex5.Text = "☆";
            this.btnindex5.UseVisualStyleBackColor = true;
            this.btnindex5.Click += new System.EventHandler(this.btnindex5_Click);
            // 
            // btnindex4
            // 
            this.btnindex4.FlatAppearance.BorderSize = 0;
            this.btnindex4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex4.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex4.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex4.Location = new System.Drawing.Point(442, 213);
            this.btnindex4.Name = "btnindex4";
            this.btnindex4.Size = new System.Drawing.Size(37, 39);
            this.btnindex4.TabIndex = 1;
            this.btnindex4.Text = "☆";
            this.btnindex4.UseVisualStyleBackColor = true;
            this.btnindex4.Click += new System.EventHandler(this.btnindex4_Click);
            // 
            // btnindex3
            // 
            this.btnindex3.FlatAppearance.BorderSize = 0;
            this.btnindex3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex3.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex3.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex3.Location = new System.Drawing.Point(442, 168);
            this.btnindex3.Name = "btnindex3";
            this.btnindex3.Size = new System.Drawing.Size(37, 39);
            this.btnindex3.TabIndex = 1;
            this.btnindex3.Text = "☆";
            this.btnindex3.UseVisualStyleBackColor = true;
            this.btnindex3.Click += new System.EventHandler(this.btnindex3_Click);
            // 
            // btnindex2
            // 
            this.btnindex2.FlatAppearance.BorderSize = 0;
            this.btnindex2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex2.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex2.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex2.Location = new System.Drawing.Point(442, 123);
            this.btnindex2.Name = "btnindex2";
            this.btnindex2.Size = new System.Drawing.Size(37, 39);
            this.btnindex2.TabIndex = 1;
            this.btnindex2.Text = "☆";
            this.btnindex2.UseVisualStyleBackColor = true;
            this.btnindex2.Click += new System.EventHandler(this.btnindex2_Click);
            // 
            // btnindex1
            // 
            this.btnindex1.FlatAppearance.BorderSize = 0;
            this.btnindex1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex1.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnindex1.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex1.Location = new System.Drawing.Point(442, 78);
            this.btnindex1.Name = "btnindex1";
            this.btnindex1.Size = new System.Drawing.Size(37, 39);
            this.btnindex1.TabIndex = 1;
            this.btnindex1.Text = "☆";
            this.btnindex1.UseVisualStyleBackColor = true;
            this.btnindex1.Click += new System.EventHandler(this.btnindex1_Click);
            // 
            // btnindex0
            // 
            this.btnindex0.FlatAppearance.BorderSize = 0;
            this.btnindex0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnindex0.Font = new System.Drawing.Font("맑은 고딕", 15F, System.Drawing.FontStyle.Bold);
            this.btnindex0.ForeColor = System.Drawing.Color.Goldenrod;
            this.btnindex0.Location = new System.Drawing.Point(442, 33);
            this.btnindex0.Name = "btnindex0";
            this.btnindex0.Size = new System.Drawing.Size(37, 39);
            this.btnindex0.TabIndex = 1;
            this.btnindex0.Text = "☆";
            this.btnindex0.UseVisualStyleBackColor = true;
            this.btnindex0.Click += new System.EventHandler(this.btnindex0_Click);
            // 
            // lv_ChartItem
            // 
            this.lv_ChartItem.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lv_ChartItem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_ChartItem.HideSelection = false;
            this.lv_ChartItem.Location = new System.Drawing.Point(3, 3);
            this.lv_ChartItem.Name = "lv_ChartItem";
            this.lv_ChartItem.Size = new System.Drawing.Size(573, 612);
            this.lv_ChartItem.TabIndex = 0;
            this.lv_ChartItem.UseCompatibleStateImageBehavior = false;
            this.lv_ChartItem.View = System.Windows.Forms.View.Details;
            this.lv_ChartItem.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lv_ChartItem_MouseDoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "종목명";
            this.columnHeader1.Width = 130;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "전마감가";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "상승률";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "상한가";
            this.columnHeader4.Width = 70;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "하한가";
            this.columnHeader5.Width = 70;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lv_interest);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(579, 618);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "관심목록";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lv_interest
            // 
            this.lv_interest.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.interestItem,
            this.interestLast,
            this.interestRate,
            this.interestMax,
            this.interestMin});
            this.lv_interest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lv_interest.HideSelection = false;
            this.lv_interest.Location = new System.Drawing.Point(3, 3);
            this.lv_interest.Name = "lv_interest";
            this.lv_interest.Size = new System.Drawing.Size(573, 612);
            this.lv_interest.TabIndex = 0;
            this.lv_interest.UseCompatibleStateImageBehavior = false;
            this.lv_interest.View = System.Windows.Forms.View.Details;
            // 
            // interestItem
            // 
            this.interestItem.Text = "종목명";
            this.interestItem.Width = 130;
            // 
            // interestLast
            // 
            this.interestLast.Text = "전마감가";
            this.interestLast.Width = 80;
            // 
            // interestRate
            // 
            this.interestRate.Text = "상승률";
            this.interestRate.Width = 80;
            // 
            // interestMax
            // 
            this.interestMax.Text = "상한가";
            this.interestMax.Width = 70;
            // 
            // interestMin
            // 
            this.interestMin.Text = "하한가";
            this.interestMin.Width = 70;
            // 
            // tabPage_save
            // 
            this.tabPage_save.BackColor = System.Drawing.Color.White;
            this.tabPage_save.Controls.Add(this.groupBox9);
            this.tabPage_save.Controls.Add(this.groupBox11);
            this.tabPage_save.Controls.Add(this.groupBox10);
            this.tabPage_save.Controls.Add(this.groupBox1);
            this.tabPage_save.Controls.Add(this.lbName2);
            this.tabPage_save.Controls.Add(this.btn_money);
            this.tabPage_save.Location = new System.Drawing.Point(4, 5);
            this.tabPage_save.Name = "tabPage_save";
            this.tabPage_save.Size = new System.Drawing.Size(602, 659);
            this.tabPage_save.TabIndex = 2;
            this.tabPage_save.Text = "tabPage5";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.label7);
            this.groupBox9.Location = new System.Drawing.Point(12, 41);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Size = new System.Drawing.Size(579, 107);
            this.groupBox9.TabIndex = 33;
            this.groupBox9.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label4.Location = new System.Drawing.Point(467, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 21);
            this.label4.TabIndex = 13;
            this.label4.Text = "총 자산";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("맑은 고딕", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(24, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(513, 40);
            this.label7.TabIndex = 14;
            this.label7.Text = "0 원";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label10);
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.Location = new System.Drawing.Point(359, 146);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Size = new System.Drawing.Size(232, 54);
            this.groupBox11.TabIndex = 35;
            this.groupBox11.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label10.Location = new System.Drawing.Point(14, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 21);
            this.label10.TabIndex = 13;
            this.label10.Text = "총 손익률";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(100, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 21);
            this.label11.TabIndex = 14;
            this.label11.Text = "0 %";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Location = new System.Drawing.Point(12, 146);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(341, 54);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label8.Location = new System.Drawing.Point(8, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 21);
            this.label8.TabIndex = 13;
            this.label8.Text = "총 평가손익";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(110, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(218, 21);
            this.label9.TabIndex = 14;
            this.label9.Text = "0 원";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Controls.Add(this.listViewHave);
            this.groupBox1.Controls.Add(this.btnSell);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.tbSearch);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.lbStockName);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(12, 202);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(579, 447);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "보유 종목 상세정보";
            // 
            // listViewHave
            // 
            this.listViewHave.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6});
            this.listViewHave.HideSelection = false;
            this.listViewHave.Location = new System.Drawing.Point(311, 95);
            this.listViewHave.Name = "listViewHave";
            this.listViewHave.Size = new System.Drawing.Size(253, 336);
            this.listViewHave.TabIndex = 36;
            this.listViewHave.UseCompatibleStateImageBehavior = false;
            this.listViewHave.View = System.Windows.Forms.View.Details;
            this.listViewHave.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewHave_MouseDoubleClick);
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "종목";
            this.columnHeader6.Width = 200;
            // 
            // btnSell
            // 
            this.btnSell.BackColor = System.Drawing.Color.LightGreen;
            this.btnSell.FlatAppearance.BorderColor = System.Drawing.Color.LightGray;
            this.btnSell.FlatAppearance.BorderSize = 0;
            this.btnSell.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSell.Location = new System.Drawing.Point(216, 23);
            this.btnSell.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(69, 41);
            this.btnSell.TabIndex = 13;
            this.btnSell.Text = "매도";
            this.btnSell.UseVisualStyleBackColor = false;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(314, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 21);
            this.label2.TabIndex = 31;
            this.label2.Text = "보유 종목 선택";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.lbEvalution);
            this.groupBox2.Controls.Add(this.lbRate3);
            this.groupBox2.Location = new System.Drawing.Point(12, 62);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(273, 61);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(9, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "평가금액";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("맑은 고딕", 9.75F);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(211, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "손익률";
            // 
            // lbEvalution
            // 
            this.lbEvalution.AutoSize = true;
            this.lbEvalution.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.lbEvalution.Location = new System.Drawing.Point(12, 34);
            this.lbEvalution.Name = "lbEvalution";
            this.lbEvalution.Size = new System.Drawing.Size(41, 21);
            this.lbEvalution.TabIndex = 11;
            this.lbEvalution.Text = "0 원";
            this.lbEvalution.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbRate3
            // 
            this.lbRate3.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.lbRate3.Location = new System.Drawing.Point(180, 34);
            this.lbRate3.Name = "lbRate3";
            this.lbRate3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbRate3.Size = new System.Drawing.Size(69, 21);
            this.lbRate3.TabIndex = 12;
            this.lbRate3.Text = "0 %";
            this.lbRate3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(313, 30);
            this.tbSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(175, 29);
            this.tbSearch.TabIndex = 33;
            this.tbSearch.Text = "보유 종목 검색";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbPrice2);
            this.groupBox3.Controls.Add(this.lbPrice);
            this.groupBox3.Location = new System.Drawing.Point(12, 117);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(273, 54);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            // 
            // lbPrice2
            // 
            this.lbPrice2.AutoSize = true;
            this.lbPrice2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbPrice2.Location = new System.Drawing.Point(8, 20);
            this.lbPrice2.Name = "lbPrice2";
            this.lbPrice2.Size = new System.Drawing.Size(74, 21);
            this.lbPrice2.TabIndex = 13;
            this.lbPrice2.Text = "매입금액";
            // 
            // lbPrice
            // 
            this.lbPrice.Location = new System.Drawing.Point(88, 20);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPrice.Size = new System.Drawing.Size(163, 21);
            this.lbPrice.TabIndex = 14;
            this.lbPrice.Text = "0 원";
            this.lbPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.LightGreen;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSearch.Location = new System.Drawing.Point(494, 30);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(70, 29);
            this.btnSearch.TabIndex = 32;
            this.btnSearch.Text = "상세보기";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // lbStockName
            // 
            this.lbStockName.AutoSize = true;
            this.lbStockName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.lbStockName.Location = new System.Drawing.Point(8, 36);
            this.lbStockName.Name = "lbStockName";
            this.lbStockName.Size = new System.Drawing.Size(55, 24);
            this.lbStockName.TabIndex = 8;
            this.lbStockName.Text = "종목명";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lbPaL2);
            this.groupBox4.Controls.Add(this.lbPaL);
            this.groupBox4.Location = new System.Drawing.Point(12, 169);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(273, 54);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            // 
            // lbPaL2
            // 
            this.lbPaL2.AutoSize = true;
            this.lbPaL2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbPaL2.Location = new System.Drawing.Point(8, 20);
            this.lbPaL2.Name = "lbPaL2";
            this.lbPaL2.Size = new System.Drawing.Size(74, 21);
            this.lbPaL2.TabIndex = 13;
            this.lbPaL2.Text = "평가손익";
            // 
            // lbPaL
            // 
            this.lbPaL.Location = new System.Drawing.Point(92, 20);
            this.lbPaL.Name = "lbPaL";
            this.lbPaL.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPaL.Size = new System.Drawing.Size(159, 21);
            this.lbPaL.TabIndex = 14;
            this.lbPaL.Text = "0 원";
            this.lbPaL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbRate2);
            this.groupBox5.Controls.Add(this.lbRate);
            this.groupBox5.Location = new System.Drawing.Point(12, 219);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(273, 54);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            // 
            // lbRate2
            // 
            this.lbRate2.AutoSize = true;
            this.lbRate2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbRate2.Location = new System.Drawing.Point(8, 20);
            this.lbRate2.Name = "lbRate2";
            this.lbRate2.Size = new System.Drawing.Size(58, 21);
            this.lbRate2.TabIndex = 13;
            this.lbRate2.Text = "손익률";
            // 
            // lbRate
            // 
            this.lbRate.Location = new System.Drawing.Point(72, 20);
            this.lbRate.Name = "lbRate";
            this.lbRate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbRate.Size = new System.Drawing.Size(177, 21);
            this.lbRate.TabIndex = 14;
            this.lbRate.Text = "0 %";
            this.lbRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.lbPresentPrice2);
            this.groupBox6.Controls.Add(this.lbPresentPrice);
            this.groupBox6.Location = new System.Drawing.Point(12, 273);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(273, 54);
            this.groupBox6.TabIndex = 24;
            this.groupBox6.TabStop = false;
            // 
            // lbPresentPrice2
            // 
            this.lbPresentPrice2.AutoSize = true;
            this.lbPresentPrice2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbPresentPrice2.Location = new System.Drawing.Point(8, 20);
            this.lbPresentPrice2.Name = "lbPresentPrice2";
            this.lbPresentPrice2.Size = new System.Drawing.Size(58, 21);
            this.lbPresentPrice2.TabIndex = 13;
            this.lbPresentPrice2.Text = "현재가";
            // 
            // lbPresentPrice
            // 
            this.lbPresentPrice.Location = new System.Drawing.Point(76, 20);
            this.lbPresentPrice.Name = "lbPresentPrice";
            this.lbPresentPrice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbPresentPrice.Size = new System.Drawing.Size(175, 21);
            this.lbPresentPrice.TabIndex = 14;
            this.lbPresentPrice.Text = "0 원";
            this.lbPresentPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lbBuyPrice2);
            this.groupBox7.Controls.Add(this.lbBuyPrice);
            this.groupBox7.Location = new System.Drawing.Point(12, 325);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(273, 54);
            this.groupBox7.TabIndex = 24;
            this.groupBox7.TabStop = false;
            // 
            // lbBuyPrice2
            // 
            this.lbBuyPrice2.AutoSize = true;
            this.lbBuyPrice2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbBuyPrice2.Location = new System.Drawing.Point(8, 20);
            this.lbBuyPrice2.Name = "lbBuyPrice2";
            this.lbBuyPrice2.Size = new System.Drawing.Size(58, 21);
            this.lbBuyPrice2.TabIndex = 13;
            this.lbBuyPrice2.Text = "매입가";
            // 
            // lbBuyPrice
            // 
            this.lbBuyPrice.Location = new System.Drawing.Point(72, 20);
            this.lbBuyPrice.Name = "lbBuyPrice";
            this.lbBuyPrice.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbBuyPrice.Size = new System.Drawing.Size(179, 21);
            this.lbBuyPrice.TabIndex = 14;
            this.lbBuyPrice.Text = "0 원";
            this.lbBuyPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lbBalance2);
            this.groupBox8.Controls.Add(this.lbBalance);
            this.groupBox8.Location = new System.Drawing.Point(12, 377);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox8.Size = new System.Drawing.Size(273, 54);
            this.groupBox8.TabIndex = 25;
            this.groupBox8.TabStop = false;
            // 
            // lbBalance2
            // 
            this.lbBalance2.AutoSize = true;
            this.lbBalance2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lbBalance2.Location = new System.Drawing.Point(8, 20);
            this.lbBalance2.Name = "lbBalance2";
            this.lbBalance2.Size = new System.Drawing.Size(74, 21);
            this.lbBalance2.TabIndex = 13;
            this.lbBalance2.Text = "잔고수량";
            // 
            // lbBalance
            // 
            this.lbBalance.Location = new System.Drawing.Point(80, 20);
            this.lbBalance.Name = "lbBalance";
            this.lbBalance.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbBalance.Size = new System.Drawing.Size(171, 21);
            this.lbBalance.TabIndex = 14;
            this.lbBalance.Text = "0 개";
            this.lbBalance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbName2
            // 
            this.lbName2.AutoSize = true;
            this.lbName2.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbName2.Location = new System.Drawing.Point(11, 10);
            this.lbName2.Name = "lbName2";
            this.lbName2.Size = new System.Drawing.Size(201, 30);
            this.lbName2.TabIndex = 31;
            this.lbName2.Text = "OOO님의 보유 현황";
            // 
            // tabPage_help
            // 
            this.tabPage_help.Controls.Add(this.tabControl1);
            this.tabPage_help.Location = new System.Drawing.Point(4, 5);
            this.tabPage_help.Name = "tabPage_help";
            this.tabPage_help.Size = new System.Drawing.Size(602, 659);
            this.tabPage_help.TabIndex = 3;
            this.tabPage_help.Text = "tabPage_help";
            this.tabPage_help.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_explain);
            this.tabControl1.Controls.Add(this.tabPage_help_in);
            this.tabControl1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabControl1.Location = new System.Drawing.Point(-1, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(590, 630);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage_explain
            // 
            this.tabPage_explain.Controls.Add(this.textBox1);
            this.tabPage_explain.Location = new System.Drawing.Point(4, 30);
            this.tabPage_explain.Name = "tabPage_explain";
            this.tabPage_explain.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_explain.Size = new System.Drawing.Size(582, 596);
            this.tabPage_explain.TabIndex = 0;
            this.tabPage_explain.Text = "용어설명";
            this.tabPage_explain.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(0, 0);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(582, 593);
            this.textBox1.TabIndex = 1;
            this.textBox1.TabStop = false;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // tabPage_help_in
            // 
            this.tabPage_help_in.Controls.Add(this.groupBox12);
            this.tabPage_help_in.Controls.Add(this.groupBox13);
            this.tabPage_help_in.Location = new System.Drawing.Point(4, 30);
            this.tabPage_help_in.Name = "tabPage_help_in";
            this.tabPage_help_in.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_help_in.Size = new System.Drawing.Size(582, 596);
            this.tabPage_help_in.TabIndex = 1;
            this.tabPage_help_in.Text = "도움말";
            this.tabPage_help_in.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.White;
            this.groupBox12.Controls.Add(this.label1);
            this.groupBox12.Controls.Add(this.label12);
            this.groupBox12.Location = new System.Drawing.Point(3, 177);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(576, 184);
            this.groupBox12.TabIndex = 5;
            this.groupBox12.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(6, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(509, 119);
            this.label1.TabIndex = 2;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(6, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 25);
            this.label12.TabIndex = 1;
            this.label12.Text = "주식투자";
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.Color.White;
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.label14);
            this.groupBox13.Location = new System.Drawing.Point(3, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(573, 182);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(6, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(517, 119);
            this.label13.TabIndex = 2;
            this.label13.Text = resources.GetString("label13.Text");
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(6, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(114, 25);
            this.label14.TabIndex = 1;
            this.label14.Text = "주식의 의미";
            // 
            // btn_mainhome
            // 
            this.btn_mainhome.BackColor = System.Drawing.Color.Transparent;
            this.btn_mainhome.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_mainhome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mainhome.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_mainhome.Location = new System.Drawing.Point(10, 4);
            this.btn_mainhome.Name = "btn_mainhome";
            this.btn_mainhome.Size = new System.Drawing.Size(81, 38);
            this.btn_mainhome.TabIndex = 2;
            this.btn_mainhome.Text = "홈";
            this.btn_mainhome.UseVisualStyleBackColor = false;
            this.btn_mainhome.Click += new System.EventHandler(this.btn_mainhome_Click);
            // 
            // btn_mainDomestic
            // 
            this.btn_mainDomestic.BackColor = System.Drawing.Color.Transparent;
            this.btn_mainDomestic.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_mainDomestic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mainDomestic.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_mainDomestic.Location = new System.Drawing.Point(97, 4);
            this.btn_mainDomestic.Name = "btn_mainDomestic";
            this.btn_mainDomestic.Size = new System.Drawing.Size(81, 38);
            this.btn_mainDomestic.TabIndex = 2;
            this.btn_mainDomestic.Text = "국내";
            this.btn_mainDomestic.UseVisualStyleBackColor = false;
            this.btn_mainDomestic.Click += new System.EventHandler(this.btn_mainDomestic_Click);
            // 
            // btn_mainLogin
            // 
            this.btn_mainLogin.BackColor = System.Drawing.Color.Transparent;
            this.btn_mainLogin.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_mainLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mainLogin.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_mainLogin.Location = new System.Drawing.Point(533, 4);
            this.btn_mainLogin.Name = "btn_mainLogin";
            this.btn_mainLogin.Size = new System.Drawing.Size(81, 38);
            this.btn_mainLogin.TabIndex = 2;
            this.btn_mainLogin.Text = "Log-In";
            this.btn_mainLogin.UseVisualStyleBackColor = false;
            this.btn_mainLogin.Click += new System.EventHandler(this.btn_mainLogin_Click);
            // 
            // lb_loginname
            // 
            this.lb_loginname.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_loginname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lb_loginname.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold);
            this.lb_loginname.ForeColor = System.Drawing.Color.Black;
            this.lb_loginname.Location = new System.Drawing.Point(529, 8);
            this.lb_loginname.Name = "lb_loginname";
            this.lb_loginname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lb_loginname.Size = new System.Drawing.Size(78, 30);
            this.lb_loginname.TabIndex = 3;
            this.lb_loginname.Text = "label1";
            this.lb_loginname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_help
            // 
            this.btn_help.BackColor = System.Drawing.Color.Transparent;
            this.btn_help.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_help.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_help.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_help.Location = new System.Drawing.Point(183, 4);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(81, 38);
            this.btn_help.TabIndex = 2;
            this.btn_help.Text = "도움말";
            this.btn_help.UseVisualStyleBackColor = false;
            this.btn_help.Click += new System.EventHandler(this.btn_help_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Transparent;
            this.btn_save.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_save.Location = new System.Drawing.Point(268, 4);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(89, 38);
            this.btn_save.TabIndex = 4;
            this.btn_save.Text = "보유현황";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_money
            // 
            this.btn_money.BackColor = System.Drawing.Color.LightGreen;
            this.btn_money.FlatAppearance.BorderSize = 0;
            this.btn_money.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_money.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_money.Location = new System.Drawing.Point(506, 13);
            this.btn_money.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_money.Name = "btn_money";
            this.btn_money.Size = new System.Drawing.Size(70, 29);
            this.btn_money.TabIndex = 32;
            this.btn_money.Text = "자산보기";
            this.btn_money.UseVisualStyleBackColor = false;
            this.btn_money.Click += new System.EventHandler(this.btn_money_Click);
            // 
            // main
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(623, 717);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.lb_loginname);
            this.Controls.Add(this.btn_mainDomestic);
            this.Controls.Add(this.btn_mainLogin);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.btn_mainhome);
            this.Controls.Add(this.tbc_main);
            this.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "main";
            this.Text = "main";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.main_FormClosed);
            this.tbc_main.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage_save.ResumeLayout(false);
            this.tabPage_save.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage_help.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_explain.ResumeLayout(false);
            this.tabPage_explain.PerformLayout();
            this.tabPage_help_in.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbc_main;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListView lv_ChartItem;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btn_mainhome;
        private System.Windows.Forms.Button btn_mainDomestic;
        private System.Windows.Forms.Button btn_mainLogin;
        private System.Windows.Forms.Label lb_loginname;
        private System.Windows.Forms.TabPage tabPage_save;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ListView lv_interest;
        private System.Windows.Forms.ColumnHeader interestItem;
        private System.Windows.Forms.ColumnHeader interestLast;
        private System.Windows.Forms.ColumnHeader interestRate;
        private System.Windows.Forms.ColumnHeader interestMax;
        private System.Windows.Forms.ColumnHeader interestMin;
        private System.Windows.Forms.Button btnindex9;
        private System.Windows.Forms.Button btnindex8;
        private System.Windows.Forms.Button btnindex7;
        private System.Windows.Forms.Button btnindex6;
        private System.Windows.Forms.Button btnindex5;
        private System.Windows.Forms.Button btnindex4;
        private System.Windows.Forms.Button btnindex3;
        private System.Windows.Forms.Button btnindex2;
        private System.Windows.Forms.Button btnindex1;
        private System.Windows.Forms.Button btnindex0;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbEvalution;
        private System.Windows.Forms.Label lbRate3;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbPrice2;
        private System.Windows.Forms.Label lbPrice;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lbStockName;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbPaL2;
        private System.Windows.Forms.Label lbPaL;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbRate2;
        private System.Windows.Forms.Label lbRate;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label lbPresentPrice2;
        private System.Windows.Forms.Label lbPresentPrice;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label lbBuyPrice2;
        private System.Windows.Forms.Label lbBuyPrice;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label lbBalance2;
        private System.Windows.Forms.Label lbBalance;
        private System.Windows.Forms.Label lbName2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.TabPage tabPage_help;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_explain;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPage_help_in;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label SSBVolume;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label SSBRate;
        private System.Windows.Forms.Label SSBPrice;
        private System.Windows.Forms.Label SSBDPrice;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label SKHVolume;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label SKHPrice;
        private System.Windows.Forms.Label SKHDPrice;
        private System.Windows.Forms.Label SKHRate;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label LGEVolume;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label LGERate;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label LGEDPrice;
        private System.Windows.Forms.Label LGEPrice;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label SSVolume;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label SSRate;
        private System.Windows.Forms.Label SSDPrice;
        private System.Windows.Forms.Label SSPrice;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label POSCOVolume;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label POSCOPrice;
        private System.Windows.Forms.Label POSCORate;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label POSCODPrice;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label SSEVolume;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label SSERate;
        private System.Windows.Forms.Label SSEDPrice;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label SSEPrice;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label LGCVolume;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label LGCPrice;
        private System.Windows.Forms.Label LGCDPrice;
        private System.Windows.Forms.Label LGCRate;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label SSSVolume;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label SSSRate;
        private System.Windows.Forms.Label SSSPrice;
        private System.Windows.Forms.Label SSSDPrice;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label HDCVolume;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label HDCDPrice;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label HDCPrice;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label HDCRate;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label ECOVolume;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label ECORate;
        private System.Windows.Forms.Label ECODPrice;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label ECOPrice;
        private System.Windows.Forms.Label lbRT10;
        private System.Windows.Forms.Label lbRT9;
        private System.Windows.Forms.Label lbRT8;
        private System.Windows.Forms.Label lbRT7;
        private System.Windows.Forms.Label lbRT6;
        private System.Windows.Forms.Label lbRT5;
        private System.Windows.Forms.Label lbRT4;
        private System.Windows.Forms.Label lbRT3;
        private System.Windows.Forms.Label lbRT2;
        private System.Windows.Forms.Label lbRT1;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label lbVO10;
        private System.Windows.Forms.Label lbVO9;
        private System.Windows.Forms.Label lbVO8;
        private System.Windows.Forms.Label lbVO6;
        private System.Windows.Forms.Label lbVO4;
        private System.Windows.Forms.Label lbVO5;
        private System.Windows.Forms.Label lbVO7;
        private System.Windows.Forms.Label lbVO3;
        private System.Windows.Forms.Label lbVO2;
        private System.Windows.Forms.Label lbVO1;
        private System.Windows.Forms.ListView listViewHave;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_10;
        private System.Windows.Forms.Button btn_;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_money;
    }
}